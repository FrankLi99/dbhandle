/*通用数据库操作处理方法,利用反射,泛型，可变参数等技术*/
package com.yli.utils;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

public class DBHandler {
	//通用 DML 操作
	public static int execDML(String sql,Object [] parameters){
		int effectCnt=0;
		//boolean retFlag=true;
		PreparedStatement preStmt=null;
		Connection conn=null;
		try {
			conn=DBConnection.getConnection();
			preStmt=conn.prepareStatement(sql);
			for(int i=0;i<parameters.length;i++){
				preStmt.setObject(i+1, parameters[i]);
			}
			effectCnt=preStmt.executeUpdate();
		} catch (SQLException e) {
			//retFlag=false;
			e.printStackTrace();
		}
		finally{
			DBConnection.closeAll(preStmt,conn);
		}
		return effectCnt;
	}
	//查询列的个数
	public static int getColCount(ResultSetMetaData meta){
		int cnt=0;
		try {
			cnt=meta.getColumnCount();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return cnt;
	}
	//查询列名返回列名数组
	public static   String[] getColNames(ResultSetMetaData meta){
			String [] colNames=new String[getColCount(meta)];
			for(int i=0;i<colNames.length;i++){
				try {
					colNames[i]=meta.getColumnLabel(i+1);
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return colNames;
	}
	//通用 query 单个 bean
	public static <T> T execQuerySingleBean(String sql,Object[] parameters,Class<T> objClass){
		T t=null;
		Connection conn=null;
		PreparedStatement preStmt=null;
		ResultSet rs=null;
		ResultSetMetaData meta=null;
		String [] colNames=null;
		Method[] methods=null;
		Object inputPara=null;
		try{
			t=objClass.newInstance();
			conn=DBConnection.getConnection();
			preStmt=conn.prepareStatement(sql);
			for(int i=0;i<parameters.length;i++){
				preStmt.setObject(i+1,parameters[i]);
			}
			rs=preStmt.executeQuery();
			meta=rs.getMetaData();
			colNames=getColNames(meta);
			methods=objClass.getMethods();
			while(rs.next()){
				for(int i=0;i<colNames.length;i++){
					inputPara=rs.getObject(i+1);  // 从 1 开始
					for(Method method:methods){
						if(inputPara!=null)
						if(("set"+colNames[i]).equalsIgnoreCase(method.getName()))
							method.invoke(t,inputPara);
					}
					
				}
			}
		}
		catch(SQLException | InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e){
			e.printStackTrace();
		}
		finally{
			DBConnection.closeAll(rs,preStmt,conn);
		}
		return t;
	}
}
