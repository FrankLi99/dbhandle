package com.yli.utils;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	private static Connection conn;
	private static String driver;
	private static String url;
	private static String name;
	private static String password;
	private final static String fileName="jdbc.properties";
	static{
		ConfigurationFileManager cfgm=ConfigurationFileManager.getInstance();
		try {
			cfgm.loadPropertiesFile(fileName);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		driver=cfgm.getValueByKey("driver");
		url=cfgm.getValueByKey("url");
		name=cfgm.getValueByKey("name");
		password=cfgm.getValueByKey("password");
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	public static Connection getConnection() throws SQLException{
		try {
			conn=DriverManager.getConnection(url,name,password);
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		}
		return conn;
	}
	
	public static void closeAll(AutoCloseable ... resources){
		for(AutoCloseable res:resources){
			if(res!=null)
				try{res.close();}
				catch(Exception e){
					e.printStackTrace();
				}
			    finally{
			    	res=null;
			    }
		}
	}
}
