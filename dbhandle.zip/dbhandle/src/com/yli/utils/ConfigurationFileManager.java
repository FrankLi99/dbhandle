package com.yli.utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;


public class ConfigurationFileManager {
	private static ConfigurationFileManager cfm;
	private ConfigurationFileManager(){}
	public static ConfigurationFileManager getInstance(){
		if(cfm==null){
			cfm=new ConfigurationFileManager();
		}
		return cfm;
	}
	private Properties property;
	public Properties loadPropertiesFile(String fileName) throws IOException{
		this.property=new Properties();
		InputStream in=ConfigurationFileManager.class.getClassLoader().getResourceAsStream(fileName);
		try {
			property.load(in);
		} catch (IOException e) {
			e.printStackTrace();
			throw e;
		}
		return property;
	}
	public String getValueByKey(String key){
		return property.getProperty(key);
	}

}
