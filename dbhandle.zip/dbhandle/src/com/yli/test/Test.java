package com.yli.test;
import java.io.IOException;
import java.lang.reflect.Proxy;

import com.yli.domain.User;
import com.yli.proxy.DaoProxy;
//import org.junit.Test;
import com.yli.utils.ConfigurationFileManager;
import com.yli.utils.DBHandler;

import dao.IUserDao;
import dao.UserDao;
public class Test {
	//@Test
	public static void testConfigurationFileManeger() throws IOException{
		ConfigurationFileManager cfgm=ConfigurationFileManager.getInstance();
		String name=null;
		cfgm.loadPropertiesFile("jdbc.properties");
		name=cfgm.getValueByKey("name");
		System.out.println(name);
	}
	public static void main(String [] args) throws IOException{
		//testConfigurationFileManeger();
		Object[] parameters=new Object[]{1,"frank","123"};
		IUserDao ud=new UserDao();
		
		User u=null;//(User)DBHandler.execQuerySingleBean("select id,name,password from users where id=? and name=? and password=?", parameters, User.class);
		u=ud.querySingle(parameters);
		System.out.println(u.getId()+"--><--"+u.getName()+"--><--"+u.getPassword());
		
		DaoProxy dp=new DaoProxy(ud);
		ud=(IUserDao)Proxy.newProxyInstance(ud.getClass().getClassLoader(), ud.getClass().getInterfaces(),dp);
		
		System.out.println(u.getId()+"--><--"+u.getName()+"--><--"+u.getPassword());
	}
}
