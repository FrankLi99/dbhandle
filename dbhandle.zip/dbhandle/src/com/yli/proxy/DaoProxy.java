package com.yli.proxy;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class DaoProxy implements InvocationHandler {
	private Object tar;
	public DaoProxy(Object tar){
		this.tar=tar;
	}
	@Override
	public Object invoke(Object proxy, Method method, Object[] parameters) throws Throwable {
		// TODO Auto-generated method stub
		Object obj=null;
		try{
			obj=method.invoke(tar, parameters);
		}
		catch(IllegalAccessException|IllegalArgumentException|InvocationTargetException e){
			e.printStackTrace();
		}
		return obj;
	}

}
