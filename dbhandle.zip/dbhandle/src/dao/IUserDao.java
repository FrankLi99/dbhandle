package dao;

import com.yli.domain.User;

public interface IUserDao extends IObjDao<User>{
	@Override
	public User querySingle(Object[] parameters);
}
