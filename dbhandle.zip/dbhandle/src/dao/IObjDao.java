package dao;

import com.yli.domain.User;

public interface IObjDao<T> {
	public boolean insert(T t);
	public boolean delete(T t);
	public boolean update(T t);
	//public T querySingle();
	public T querySingle(Object[] parameters);
}
