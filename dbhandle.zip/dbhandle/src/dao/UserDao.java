package dao;

import com.yli.domain.User;
import com.yli.utils.DBHandler;

public class UserDao implements IUserDao {

	@Override
	public boolean insert(User t) {
		boolean flag=false;
		String sql="insert into users(id,name,password) values(?,?,?)";
		Object [] parameters=new Object[]{t.getId(),t.getName(),t.getPassword()};
		if(DBHandler.execDML(sql, parameters)>0){
			flag=true;
		}
		return flag;
		// return (DBHandler.execDML(sql, parameters)>0)?true:false;
	}

	@Override
	public boolean delete(User t) {
		// TODO Auto-generated method stub
		System.out.println("delete");
		return false;
	}

	@Override
	public boolean update(User t) {
		System.out.println("update");
		return false;
	}
    @Override
	public User querySingle(Object[] parameters) {
		String sql="select id,name,password from users where id=? and name=? and password=?";
		return DBHandler.execQuerySingleBean(sql, parameters, User.class);
	}

}
